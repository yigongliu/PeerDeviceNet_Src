package com.xconns.samples.MsgLoop;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.xconns.peerdevicenet.DeviceInfo;
import com.xconns.peerdevicenet.Router;


public class ChatByIntentingActivity extends Activity {
	// Debugging
	private static final String TAG = "ChatByIntentingActivity";

	ArrayList<DeviceInfo> peers = new ArrayList<DeviceInfo>();
	DeviceComparator devCompare = new DeviceComparator();
	String myAddr = null;
	//
	private static final String groupId = "MsgLoop";
	private ArrayAdapter<String> mChatArrayAdapter;
	private ListView mChatView;
	private EditText mOutMsgText;
	private Button mSendButton;
	int count = 0;
	int numPeer = 0;

	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);

		// Initialize the array adapter for the conversation thread
		mChatArrayAdapter = new ArrayAdapter<String>(this, R.layout.message);
		mChatView = (ListView) findViewById(R.id.chat_msgs);
		mChatView.setAdapter(mChatArrayAdapter);

		// Initialize the compose field with a listener for the return key
		mOutMsgText = (EditText) findViewById(R.id.msg_out);
		mOutMsgText
				.setOnEditorActionListener(new TextView.OnEditorActionListener() {
					public boolean onEditorAction(TextView view, int actionId,
							KeyEvent event) {
						// If the action is a key-up event on the return key,
						// send the message
						if (actionId == EditorInfo.IME_NULL
								&& event.getAction() == KeyEvent.ACTION_UP) {
							String message = view.getText().toString();
							view.setText("");
							sendMsg(message);
						}
						return true;
					}
				});

		// Initialize the send button with a listener that for click events
		mSendButton = (Button) findViewById(R.id.button_send);
		mSendButton.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				String message = mOutMsgText.getText().toString();
				sendMsg(message);
				mOutMsgText.setText("");
			}
		});
		mSendButton.setEnabled(false);
		
		myAddr = getLocalIpAddr();
		Log.d(TAG, "my ip="+myAddr);



		// register broadcast recvers
		IntentFilter filter = new IntentFilter();
		filter.addAction(Router.ACTION_RECV_MSG);
		filter.addAction(Router.ACTION_SELF_JOIN);
		filter.addAction(Router.ACTION_PEER_JOIN);
		filter.addAction(Router.ACTION_PEER_LEAVE);
		filter.addAction(Router.ACTION_ERROR);
		registerReceiver(mReceiver, filter);

		// start router service
		// join "WifiChat" group
		Intent intent = new Intent(Router.ACTION_JOIN_GROUP);
		intent.putExtra(Router.GROUP_ID, groupId);
		startService(intent);
	}

	@Override
	public void onDestroy() {
		super.onDestroy();
		// Leave "WifiChat" group
		Intent intent = new Intent(Router.ACTION_LEAVE_GROUP);
		intent.putExtra(Router.GROUP_ID, groupId);
		startService(intent);
		// unregister recvers
		unregisterReceiver(mReceiver);
	}

	private void sendMsg(String msg) {
		// show my msg first
		mChatArrayAdapter.add("Me: " + msg);
		// find dest dev
		DeviceInfo dev = findNext();
		// send my msg
		Intent intent = new Intent(Router.ACTION_SEND_MSG);
		intent.putExtra(Router.GROUP_ID, groupId);
		intent.putExtra(Router.MSG_DATA, msg.getBytes());
		intent.putExtra(Router.PEER_NAME, dev.name);
		intent.putExtra(Router.PEER_ADDR, dev.addr);
		intent.putExtra(Router.PEER_PORT, dev.port);
		startService(intent);
	}

	private BroadcastReceiver mReceiver = new BroadcastReceiver() {

		@Override
		public void onReceive(Context context, Intent intent) {
			final String action = intent.getAction();
			if (Router.ACTION_SELF_JOIN.equals(action)) {
				// append peer msg to chat area
				String[] pnames = intent.getStringArrayExtra(Router.PEER_NAMES);
				String[] paddrs = intent.getStringArrayExtra(Router.PEER_ADDRS);
				String[] pports = intent.getStringArrayExtra(Router.PEER_PORTS);
				if (pnames != null && pnames.length > 0 && paddrs != null
						&& paddrs.length > 0) {
					numPeer = pnames.length;
					Log.d(TAG, "self_join found peers: " + numPeer);
					for (int i = 0; i < numPeer; i++) {
						mChatArrayAdapter.add("Peer join : " + pnames[i] + ": "
								+ paddrs[i]);
						DeviceInfo dev = new DeviceInfo(pnames[i], paddrs[i], pports[i]);
						peers.add(dev);
					}
					Collections.sort(peers, devCompare);
					mSendButton.setEnabled(true);
				}
			} else if (Router.ACTION_PEER_JOIN.equals(action)) {
				// append peer msg to chat area
				String pname = intent.getStringExtra(Router.PEER_NAME);
				String paddr = intent.getStringExtra(Router.PEER_ADDR);
				String pport = intent.getStringExtra(Router.PEER_PORT);
				if (pname != null && paddr != null) {
					mChatArrayAdapter
							.add("Peer join : " + pname + ": " + paddr);
					DeviceInfo dev = new DeviceInfo(pname, paddr, pport);
					peers.add(dev);
					numPeer++;
					Collections.sort(peers, devCompare);
					mSendButton.setEnabled(true);
				}
			} else if (Router.ACTION_PEER_LEAVE.equals(action)) {
				// append peer msg to chat area
				String pname = intent.getStringExtra(Router.PEER_NAME);
				String paddr = intent.getStringExtra(Router.PEER_ADDR);
				if (pname != null && paddr != null) {
					mChatArrayAdapter.add("Peer leave : " + pname + ": "
							+ paddr);
					numPeer--;
					for(DeviceInfo d: peers) {
						if (d.addr.equals(paddr)) {
							peers.remove(d);
							break;
						}
					}
					if (numPeer <= 0) {
						numPeer = 0;
						mSendButton.setEnabled(false);
					}
				}
			} else if (Router.ACTION_RECV_MSG.equals(action)) {
				// append peer msg to chat area
				byte[] msg = intent.getByteArrayExtra(Router.MSG_DATA);
				String pname = intent.getStringExtra(Router.PEER_NAME);
				String paddr = intent.getStringExtra(Router.PEER_ADDR);
				mChatArrayAdapter.add(pname+"("+paddr+") send "+count+": " + new String(msg));
				count++;
				sendMsg(new String(msg));
			} else if (Router.ACTION_ERROR.equals(action)) {
				String msg = intent.getStringExtra(Router.MSG_DATA);
				mChatArrayAdapter.add(msg);
				// Toast.makeText(ChatByIntentingActivity.this,
				// "connection failed: "+msg, Toast.LENGTH_SHORT).show();
			}
		}
	};
	
	
	DeviceInfo findNext() {
		DeviceInfo dest = null;
		for(DeviceInfo dev: peers) {
			if (myAddr.compareTo(dev.addr) < 0) {
				dest = dev;
				break;
			}
		}
		if (dest == null) {
			dest = peers.get(0);
		}
		return dest;
	}


	public static String getLocalIpAddr() {
		try {
			for (Enumeration<NetworkInterface> en = NetworkInterface
					.getNetworkInterfaces(); en.hasMoreElements();) {
				NetworkInterface intf = en.nextElement();
				for (Enumeration<InetAddress> enumIpAddr = intf
						.getInetAddresses(); enumIpAddr.hasMoreElements();) {
					InetAddress inetAddress = enumIpAddr.nextElement();
					if (!inetAddress.isLoopbackAddress()
							&& inetAddress instanceof Inet4Address) {
						return inetAddress.getHostAddress();
					}
				}
			}
		} catch (SocketException ex) {
			Log.e(TAG, ex.toString());
		}
		return null;
	}
	

}