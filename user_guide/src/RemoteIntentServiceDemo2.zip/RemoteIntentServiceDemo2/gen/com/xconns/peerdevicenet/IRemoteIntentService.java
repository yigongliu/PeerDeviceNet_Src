/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Original file: /home/yigong/Workspaces/Workspace/JavaWorkspace/eclipse_workspace_2012/RemoteIntentServiceDemo2/src/com/xconns/peerdevicenet/IRemoteIntentService.aidl
 */
package com.xconns.peerdevicenet;
public interface IRemoteIntentService extends android.os.IInterface
{
/** Local-side IPC implementation stub class. */
public static abstract class Stub extends android.os.Binder implements com.xconns.peerdevicenet.IRemoteIntentService
{
private static final java.lang.String DESCRIPTOR = "com.xconns.peerdevicenet.IRemoteIntentService";
/** Construct the stub at attach it to the interface. */
public Stub()
{
this.attachInterface(this, DESCRIPTOR);
}
/**
 * Cast an IBinder object into an com.xconns.peerdevicenet.IRemoteIntentService interface,
 * generating a proxy if needed.
 */
public static com.xconns.peerdevicenet.IRemoteIntentService asInterface(android.os.IBinder obj)
{
if ((obj==null)) {
return null;
}
android.os.IInterface iin = (android.os.IInterface)obj.queryLocalInterface(DESCRIPTOR);
if (((iin!=null)&&(iin instanceof com.xconns.peerdevicenet.IRemoteIntentService))) {
return ((com.xconns.peerdevicenet.IRemoteIntentService)iin);
}
return new com.xconns.peerdevicenet.IRemoteIntentService.Stub.Proxy(obj);
}
public android.os.IBinder asBinder()
{
return this;
}
@Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
{
switch (code)
{
case INTERFACE_TRANSACTION:
{
reply.writeString(DESCRIPTOR);
return true;
}
case TRANSACTION_startRemoteActivity:
{
data.enforceInterface(DESCRIPTOR);
com.xconns.peerdevicenet.DeviceInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.xconns.peerdevicenet.DeviceInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
android.content.Intent _arg1;
if ((0!=data.readInt())) {
_arg1 = android.content.Intent.CREATOR.createFromParcel(data);
}
else {
_arg1 = null;
}
com.xconns.peerdevicenet.IRemoteIntentHandler _arg2;
_arg2 = com.xconns.peerdevicenet.IRemoteIntentHandler.Stub.asInterface(data.readStrongBinder());
this.startRemoteActivity(_arg0, _arg1, _arg2);
return true;
}
case TRANSACTION_startRemoteActivityForResult:
{
data.enforceInterface(DESCRIPTOR);
com.xconns.peerdevicenet.DeviceInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.xconns.peerdevicenet.DeviceInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
android.content.Intent _arg1;
if ((0!=data.readInt())) {
_arg1 = android.content.Intent.CREATOR.createFromParcel(data);
}
else {
_arg1 = null;
}
com.xconns.peerdevicenet.IRemoteIntentHandler _arg2;
_arg2 = com.xconns.peerdevicenet.IRemoteIntentHandler.Stub.asInterface(data.readStrongBinder());
this.startRemoteActivityForResult(_arg0, _arg1, _arg2);
return true;
}
case TRANSACTION_startRemoteService:
{
data.enforceInterface(DESCRIPTOR);
com.xconns.peerdevicenet.DeviceInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.xconns.peerdevicenet.DeviceInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
android.content.Intent _arg1;
if ((0!=data.readInt())) {
_arg1 = android.content.Intent.CREATOR.createFromParcel(data);
}
else {
_arg1 = null;
}
com.xconns.peerdevicenet.IRemoteIntentHandler _arg2;
_arg2 = com.xconns.peerdevicenet.IRemoteIntentHandler.Stub.asInterface(data.readStrongBinder());
this.startRemoteService(_arg0, _arg1, _arg2);
return true;
}
case TRANSACTION_sendRemoteBroadcast:
{
data.enforceInterface(DESCRIPTOR);
com.xconns.peerdevicenet.DeviceInfo _arg0;
if ((0!=data.readInt())) {
_arg0 = com.xconns.peerdevicenet.DeviceInfo.CREATOR.createFromParcel(data);
}
else {
_arg0 = null;
}
android.content.Intent _arg1;
if ((0!=data.readInt())) {
_arg1 = android.content.Intent.CREATOR.createFromParcel(data);
}
else {
_arg1 = null;
}
com.xconns.peerdevicenet.IRemoteIntentHandler _arg2;
_arg2 = com.xconns.peerdevicenet.IRemoteIntentHandler.Stub.asInterface(data.readStrongBinder());
this.sendRemoteBroadcast(_arg0, _arg1, _arg2);
return true;
}
case TRANSACTION_cancelSession:
{
data.enforceInterface(DESCRIPTOR);
int _arg0;
_arg0 = data.readInt();
this.cancelSession(_arg0);
return true;
}
}
return super.onTransact(code, data, reply, flags);
}
private static class Proxy implements com.xconns.peerdevicenet.IRemoteIntentService
{
private android.os.IBinder mRemote;
Proxy(android.os.IBinder remote)
{
mRemote = remote;
}
public android.os.IBinder asBinder()
{
return mRemote;
}
public java.lang.String getInterfaceDescriptor()
{
return DESCRIPTOR;
}
public void startRemoteActivity(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((device!=null)) {
_data.writeInt(1);
device.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
if ((intent!=null)) {
_data.writeInt(1);
intent.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((h!=null))?(h.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_startRemoteActivity, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void startRemoteActivityForResult(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((device!=null)) {
_data.writeInt(1);
device.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
if ((intent!=null)) {
_data.writeInt(1);
intent.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((h!=null))?(h.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_startRemoteActivityForResult, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void startRemoteService(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((device!=null)) {
_data.writeInt(1);
device.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
if ((intent!=null)) {
_data.writeInt(1);
intent.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((h!=null))?(h.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_startRemoteService, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void sendRemoteBroadcast(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
if ((device!=null)) {
_data.writeInt(1);
device.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
if ((intent!=null)) {
_data.writeInt(1);
intent.writeToParcel(_data, 0);
}
else {
_data.writeInt(0);
}
_data.writeStrongBinder((((h!=null))?(h.asBinder()):(null)));
mRemote.transact(Stub.TRANSACTION_sendRemoteBroadcast, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
public void cancelSession(int sessionId) throws android.os.RemoteException
{
android.os.Parcel _data = android.os.Parcel.obtain();
try {
_data.writeInterfaceToken(DESCRIPTOR);
_data.writeInt(sessionId);
mRemote.transact(Stub.TRANSACTION_cancelSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
}
finally {
_data.recycle();
}
}
}
static final int TRANSACTION_startRemoteActivity = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
static final int TRANSACTION_startRemoteActivityForResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
static final int TRANSACTION_startRemoteService = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
static final int TRANSACTION_sendRemoteBroadcast = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
static final int TRANSACTION_cancelSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
}
public void startRemoteActivity(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException;
public void startRemoteActivityForResult(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException;
public void startRemoteService(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException;
public void sendRemoteBroadcast(com.xconns.peerdevicenet.DeviceInfo device, android.content.Intent intent, com.xconns.peerdevicenet.IRemoteIntentHandler h) throws android.os.RemoteException;
public void cancelSession(int sessionId) throws android.os.RemoteException;
}
