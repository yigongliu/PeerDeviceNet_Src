/** Automatically generated file. DO NOT MODIFY */
package com.xconns.samples.RemoteIntentServiceDemo2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}